A Pen created at CodePen.io. You can find this one at https://codepen.io/Richard-Howard-Toronto/pen/VGEdJy.

 Honey Jar created with layered backgrounds and clip-path. I used a background gradient for the lid  🍯🐝